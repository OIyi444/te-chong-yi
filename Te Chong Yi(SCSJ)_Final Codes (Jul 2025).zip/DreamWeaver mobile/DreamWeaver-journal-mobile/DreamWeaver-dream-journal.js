
        // Modal functionality
        const dreamModal = document.getElementById('dreamModal');
        const newDreamBtn = document.getElementById('newDreamBtn');
        const closeModal = document.getElementById('closeModal');
        
        newDreamBtn.addEventListener('click', () => {
            dreamModal.classList.add('active');
        });
        
        closeModal.addEventListener('click', () => {
            dreamModal.classList.remove('active');
        });
        
        // Tag selection functionality
        const tagOptions = document.querySelectorAll('.tag-option');
        tagOptions.forEach(tag => {
            tag.addEventListener('click', () => {
                tag.classList.toggle('selected');
            });
        });
        
        // Calendar day selection
        const calendarDays = document.querySelectorAll('.calendar-day');
        calendarDays.forEach(day => {
            day.addEventListener('click', () => {
                calendarDays.forEach(d => d.classList.remove('active'));
                day.classList.add('active');
            });
        });
        
        // Filter tag selection
        const filterTags = document.querySelectorAll('.filter-tag');
        filterTags.forEach(tag => {
            tag.addEventListener('click', () => {
                if (tag.textContent === 'All') {
                    filterTags.forEach(t => t.classList.remove('active'));
                    tag.classList.add('active');
                } else {
                    document.querySelector('.filter-tag:first-child').classList.remove('active');
                    tag.classList.toggle('active');
                }
            });
        });
